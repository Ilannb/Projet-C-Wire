#ifndef DATA_H
#define DATA_H

typedef struct Centrale{
  struct centrale* HVB;
  
}Centrale;

#endif