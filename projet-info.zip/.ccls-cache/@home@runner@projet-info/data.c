#include <stdio.h>
#include <stdlib.h>
#include "avl.h"

int somme(AVL* s){

  
  
}