#ifndef DATA_H
#define DATA_H

typedef struct station{
  int ID;
  int capacite;
  int conso;
}Station;

#endif