#!/bin/bash

if [ -z "$1" ]; then
  echo "Le fichier c-wire n'est pas fourni, veuillez réessayer."
  exit 1
fi

c_wire="$1" #nom à méditer

if [ ! -f "c-wire"$1 ]; then
  echo "Il n'y a pas de fichier '$c_wire'"
  exit 1
fi

echo "Le fichier d'entrée : $c_wire"

#type de station :

HVB="$2"
HVA="$3"
LV="$4"

#type de consommateur : 

COMP="$5"
INDIV="$6"
ALL="$7"

#ID centrale (optionnel):

IDC="$8" 

#Option d'aide(-h)(optionnel):

